package PasoDeObjetos;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Bloque {

    int a,b,c;
    int volumen;
    
    Bloque(int i, int j, int k){
        a = i;
        b = j;
        c = k;
        volumen = a * b * c;  
    }
    
    //Devuelve true si ob define el mismo bloque
    boolean mismoBloque(Bloque ob){
        if ((ob.a == a) && (ob.b == b) && (ob.c ==c)) return true;
        else return false;
    }
    
    //Regresa true si ob tiene el mismo volumen
    boolean mismoVolumen(Bloque ob){
        if(ob.volumen == volumen) return true;
        else return false;
    }    
}
