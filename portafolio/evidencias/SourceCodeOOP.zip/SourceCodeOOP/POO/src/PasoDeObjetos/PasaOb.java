package PasoDeObjetos;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class PasaOb {
    public static void main(String args[]){
        Bloque ob1 = new Bloque(10,2,5);
        Bloque ob2 = new Bloque(10,2,5);
        Bloque ob3 = new Bloque(4,5,5);
        
        System.out.println("ob1 mismas dimensiones que ob2:" +ob1.mismoBloque(ob2));
        System.out.println("ob1 mismas dimensiones que ob3:" +ob1.mismoBloque(ob3));
        System.out.println("ob1 mismo volumen que ob3:" +ob1.mismoVolumen(ob3));        
    }
}
