package Argumentos;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class LlamadaPorValor {
    public static void main(String args[]){
        Prueba ob = new Prueba();
        int a = 15, b = 20;
         System.out.println("a y b antes de la llamada:" + a + " "+b);
         ob.NoCambio(a, b);
         System.out.println(a +" "+b);
    }
}
