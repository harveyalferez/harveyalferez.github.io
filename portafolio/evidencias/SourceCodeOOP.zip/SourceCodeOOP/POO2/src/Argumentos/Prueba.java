package Argumentos;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Prueba {
    //Este metodo no le genera cambios al argumento usado en la llamada
    void NoCambio(int i, int j){
        i = i + j;
        j = -j;
        System.out.println("i y j"+i+" "+j);
    }
}
