/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class LlamadaPorRef {
    public static void main(String args[]){
        Prueba ob = new Prueba(15, 20);
        
        System.out.println("ob.a y ob.b antes de la llamada:" +ob.a + " "+ob.b);
        
        ob.cambio(ob);
        
        System.out.println("ob.a y ob.b tras la llamada:"+ob.a +" "+ob.b);
    }
}
