/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Prueba {
    int a, b;
    
    Prueba(int i, int j){
        a = i;
        b = j;
    }
    
    //Pasa un objeto. Ahora, seran cambiados en la llamada ob.a y ob.b usados
    
    void cambio (Prueba ob){
        ob.a = ob.a + ob.b;
        ob.b = -ob.b;
    }
}
