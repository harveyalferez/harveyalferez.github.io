/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Err {
    String msj; //mensaje de eror
    int severidad ; //codigo que indica severidad de error
    
    Err(String m, int s){
        msj = m;
        severidad = s;
    }
}
