/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class InfoError {
    String msjs[] = {
        "Error de salida",
        "Error de entrada",
        "Disco lleno",
        "Indice fuera de limites"
    };
    
    int malo[] = {3, 3, 2, 4};
    
    Err obtenerInfoError(int i){ //REGRESA UN OBJETO DE TIPO ERR!!!
        if(i >= 0 & i < msjs.length)
            return new Err(msjs[i], malo[i]);
        else
            return new Err("El codigo de error no existe", 0);
    }
}
