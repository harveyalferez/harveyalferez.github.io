/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Recursion {
    public static void main(String args[]){
        Factorial f = new Factorial();
        System.out.println("Factorial de 3 es"+f.factR(3));
    }
}
