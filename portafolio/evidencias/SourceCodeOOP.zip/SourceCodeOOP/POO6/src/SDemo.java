/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class SDemo {
    public static void main(String args[]){
        StaticDemo ob1 = new StaticDemo();
        StaticDemo ob2 = new StaticDemo();
        
        //Cada objeto tiene su propia copia de una variable de instancia
        ob1.x = 10;
        ob2.x = 20;
        System.out.println("Por supuesto, ob1.x y ob2.x son independientes");
        System.out.println(ob1.x + " "+ob2.x);
        
        //Cada objeto comparte una copia de una variable static
        System.out.println("Se comparte la variable y");
        ob1.y = 19;
        System.out.println(ob1.y +" "+ob2.y);
        StaticDemo.y = 11;
        System.out.println(StaticDemo.y+" "+ob1.y+" "+ob2.y);
    }
            
}
