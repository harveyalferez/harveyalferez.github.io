/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */


enum Transporte{
    AUTO, CAMIONETA, AEROPLANO, TREN, BOTE
}

public class EnumDemo { 
    public static void main(String args[]){
        Transporte tp;
        tp = Transporte.AEROPLANO;
        System.out.println("Valor de tp: " +tp);
    }    
}
