/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */

enum Transporte{
    AUTO, CAMIONETA, AEROPLANO, TREN, BOTE
}

public class EnumDemo2 {
    public static void main(String args[]){
        Transporte tp;
        System.out.println("He aqui todas las contantes de transporte :)");
        
        //uso de values()
        Transporte todosTransportes[] = Transporte.values(); //Obtiene una matriz de constantes de Transporte
        for(Transporte t:todosTransportes)
            System.out.println(t);
      
        System.out.println();
        
        //uso de valueOf()
        tp = Transporte.valueOf("AEROPLANO"); //Obtiene la constante con el nombre aeroplano
        System.out.println("tp contiene "+tp);
    }
}
