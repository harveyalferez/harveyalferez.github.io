//Uso de un constructor, una variable de instancia y un método de enum

enum Transporte{
    //Observe lo valores de inicializacion
    //Se especifican los argumentaos del constructor despues de cada constante
    AUTO(90), CAMIONETA(75), AEROPLANO(960), TREN(110), BOTE(30); 
    
    //Cuando una enumeracion contine otros mienbros, la lista de numeros debe terminar con ;
    
    private int velocidad; //velocidad tipica para cada transporte. Es una variable de instancia
    
    //Constructor
    Transporte(int v){
        velocidad = v;
    }
    
    int obtenerVelocidad(){ 
        return velocidad;
    }
}

public class EnumDemo3 {
    public static void main(String args[])
    {
        Transporte tp;//Cuando la variable tp se declara en main(),
        //se llama al constructor de Transpote una vez para cada constante
        //especificada
        
        System.out.println(Transporte.AEROPLANO.obtenerVelocidad());
        
        //Debido a que cada constante de enumeracion contiene su propia copia de velocidad,
        //puede obtener la velocidad de un tipo especifico de transporte al llamar a
        //obtenerVelocidad()
        
        for(Transporte t: Transporte.values()){
            System.out.println(t + " la velocidad tipica es " + t.obtenerVelocidad());
        }
        
    }
}
